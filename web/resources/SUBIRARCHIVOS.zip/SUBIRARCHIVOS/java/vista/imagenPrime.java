/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import org.primefaces.model.StreamedContent;

/**
 *
 * @author User
 */
public class imagenPrime {
    private int codImagen;
    private String nombreImagen;
    private StreamedContent graphicText;

    /**
     * @return the codImagen
     */
    public int getCodImagen() {
        return codImagen;
    }

    /**
     * @param codImagen the codImagen to set
     */
    public void setCodImagen(int codImagen) {
        this.codImagen = codImagen;
    }

    /**
     * @return the nombreImagen
     */
    public String getNombreImagen() {
        return nombreImagen;
    }

    /**
     * @param nombreImagen the nombreImagen to set
     */
    public void setNombreImagen(String nombreImagen) {
        this.nombreImagen = nombreImagen;
    }

    /**
     * @return the graphicText
     */
    public StreamedContent getGraphicText() {
        return graphicText;
    }

    /**
     * @param graphicText the graphicText to set
     */
    public void setGraphicText(StreamedContent graphicText) {
        this.graphicText = graphicText;
    }
    
}
