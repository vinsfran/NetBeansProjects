package controlador;

import dao.TiposDao;
import dao.TiposDaoImp;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.servlet.http.HttpSession;
import modelo.Tipos;
import navegacion.ActualizarCentroBean;

@ManagedBean
@SessionScoped
public class TiposController {

    private Tipos tipo;
    private DataModel listaTipos;
    private List<Tipos> listaTipos2;
    private boolean mostrarDialogo;
    private String crearActualizar;

    public TiposController() {
        this.mostrarDialogo = false;
    }

    public void listarTiposAutopartes() {
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
        //Se recupera el bean de sesion para redireccionar
        ActualizarCentroBean actualizarCentroBean = (ActualizarCentroBean) session.getAttribute("actualizarCentroBean");
        actualizarCentroBean.setIncluirPagina("./listarAdminTipos.xhtml");
        session.setAttribute("actualizarCentroBean", actualizarCentroBean);
        setListaTipos(new ListDataModel(new TiposDaoImp().lista()));
    }

    public void mostrarVentanaDialogo(String accion) {
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
        //Se recupera el bean de sesion para redireccionar
        ActualizarCentroBean actualizarCentroBean = (ActualizarCentroBean) session.getAttribute("actualizarCentroBean");
        actualizarCentroBean.setIncluirPagina("./formTiposAutopartes.xhtml");
        session.setAttribute("actualizarCentroBean", actualizarCentroBean);
        this.setCrearActualizar(accion);
        if (accion.equals("Crear")) {
            setTipo(new Tipos());
        } else if (accion.equals("Actualizar")) {
            setTipo((Tipos) (getListaTipos().getRowData()));
        }
    }

    public void crearActualizarTiposAutoparte(String accion) {
        if (accion.equals("aceptar")) {
            if (getCrearActualizar().equals("Crear")) {
                TiposDao dao = new TiposDaoImp();
                dao.guardar(getTipo());
            } else if (getCrearActualizar().equals("Actualizar")) {
                TiposDao dao = new TiposDaoImp();
                dao.actualizar(getTipo());
            }
            setCrearActualizar("");
        } else if (accion.equals("cancelar")) {
            setCrearActualizar("");
        }
        setTipo(null);
        listarTiposAutopartes();
    }

    public List<Tipos> getListaTipos2() {
        listaTipos2 = new TiposDaoImp().lista();
        return listaTipos2;
    }

    public String prepararAdicionarTipos() {
        setTipo(new Tipos());
        return "gerenciarTipos";
    }

    public String prepararAlterarTipos() {
        setTipo((Tipos) (getListaTipos().getRowData()));
        return "gerenciarTipos";
    }

    public String adicionarTipos() {
        TiposDao dao = new TiposDaoImp();
//        dao.guardar(tipo);
        return "indexTipos";
    }

    public String alterarTipos() {
        TiposDao dao = new TiposDaoImp();
//        dao.actualizar(tipo);
        return "index";
    }

    /**
     * @return the crearActualizar
     */
    public String getCrearActualizar() {
        return crearActualizar;
    }

    /**
     * @param crearActualizar the crearActualizar to set
     */
    public void setCrearActualizar(String crearActualizar) {
        this.crearActualizar = crearActualizar;
    }

    /**
     * @return the mostrarDialogo
     */
    public boolean isMostrarDialogo() {
        return mostrarDialogo;
    }

    /**
     * @param mostrarDialogo the mostrarDialogo to set
     */
    public void setMostrarDialogo(boolean mostrarDialogo) {
        this.mostrarDialogo = mostrarDialogo;
    }

    /**
     * @return the tipo
     */
    public Tipos getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(Tipos tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the listaTipos
     */
    public DataModel getListaTipos() {
        return listaTipos;
    }

    /**
     * @param listaTipos the listaTipos to set
     */
    public void setListaTipos(DataModel listaTipos) {
        this.listaTipos = listaTipos;
    }
}