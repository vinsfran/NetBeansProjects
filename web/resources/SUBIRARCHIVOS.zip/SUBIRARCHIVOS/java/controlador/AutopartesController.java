package controlador;

import dao.AutopartesDao;
import dao.AutopartesDaoImp;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import modelo.Autopartes;
import modelo.Tipos;
import navegacion.ActualizarCentroBean;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

@ManagedBean
@SessionScoped
public class AutopartesController {

    private Autopartes autoparte;
    private DataModel listaAutopartes;
    private List<Autopartes> listaAutopartes2;
    private String crearActualizar;
    private String valueBotonImagen;
    private String titleBotonImagen;
    private String iconBotonImagen;
    private String buscarExpresion;

    public AutopartesController() {
    }

    public void mostrarListarAdminAutopartes() {
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
        //Se recupera el bean de sesion para redireccionar
        ActualizarCentroBean actualizarCentroBean = (ActualizarCentroBean) session.getAttribute("actualizarCentroBean");
        actualizarCentroBean.setIncluirPagina("./listarAdminAutopartes.xhtml");
        session.setAttribute("actualizarCentroBean", actualizarCentroBean);
        setListaAutopartes2(new AutopartesDaoImp().lista());
        setListaAutopartes(new ListDataModel(getListaAutopartes2()));
    }

    public void mostrarListarAdminAutopartes2() {
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
        //Se recupera el bean de sesion para redireccionar
        ActualizarCentroBean actualizarCentroBean = (ActualizarCentroBean) session.getAttribute("actualizarCentroBean");
        actualizarCentroBean.setIncluirPagina("./listarrepuestos.xhtml");
        session.setAttribute("actualizarCentroBean", actualizarCentroBean);
        setListaAutopartes2(new AutopartesDaoImp().lista());
        setListaAutopartes(new ListDataModel(getListaAutopartes2()));
    }

    public void mostrarFormAutopartes(String accion) {
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
        //Se recupera el bean de sesion para redireccionar
        ActualizarCentroBean actualizarCentroBean = (ActualizarCentroBean) session.getAttribute("actualizarCentroBean");
        actualizarCentroBean.setIncluirPagina("./formAutopartes.xhtml");
        session.setAttribute("actualizarCentroBean", actualizarCentroBean);
        this.setCrearActualizar(accion);
        if (accion.equals("Crear")) {
            setAutoparte(new Autopartes());
            getAutoparte().setTipo(new Tipos());
        } else if (accion.equals("Actualizar")) {
            setAutoparte((Autopartes) (getListaAutopartes().getRowData()));
        }
    }

    public void crearActualizarAutoparte(String accion) {
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
        //Se recupera el bean de sesion para redireccionar
        ActualizarCentroBean actualizarCentroBean = (ActualizarCentroBean) session.getAttribute("actualizarCentroBean");
        actualizarCentroBean.setIncluirPagina("./listarAdminAutopartes.xhtml");
        session.setAttribute("actualizarCentroBean", actualizarCentroBean);
        if (accion.equals("aceptar")) {
            if (crearActualizar.equals("Crear")) {
                AutopartesDao dao = new AutopartesDaoImp();
                dao.guardar(getAutoparte());
            } else if (crearActualizar.equals("Actualizar")) {
                AutopartesDao dao = new AutopartesDaoImp();
                dao.actualizar(getAutoparte());
            }
            mostrarListarAdminAutopartes();
        } else if (accion.equals("cancelar")) {
            setAutoparte(null);
        }
    }

    public void buscar() {
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
        //Se recupera el bean de sesion para redireccionar
        ActualizarCentroBean actualizarCentroBean = (ActualizarCentroBean) session.getAttribute("actualizarCentroBean");
        actualizarCentroBean.setIncluirPagina("./listarrepuestos.xhtml");
        session.setAttribute("actualizarCentroBean", actualizarCentroBean);
        setBuscarExpresion(getBuscarExpresion().trim());
        StringTokenizer tokens = new StringTokenizer(getBuscarExpresion());
        StringBuilder buff = new StringBuilder();
        while (tokens.hasMoreTokens()) {
            buff.append("%").append(tokens.nextToken());
        }
        String resultado = buff.toString();
        setListaAutopartes2(new AutopartesDaoImp().buscar(resultado.toUpperCase()));
        setListaAutopartes(new ListDataModel(getListaAutopartes2()));
    }

    public String cambiarTituloBotonImagen(int cantidadImagen) {
        if (cantidadImagen > 0) {
            valueBotonImagen = "Ver Imagenes";
            titleBotonImagen = "Click para ver todas las imagenes";
            iconBotonImagen = "ui-icon-check";
        } else {
            valueBotonImagen = "Sin imagenes";
            titleBotonImagen = "Click para cargar imagenes";
            iconBotonImagen = "ui-icon-close";
        }
        return valueBotonImagen;
    }

    public String excluirAutopartes() {
        Autopartes autoparteTemp = (Autopartes) (getListaAutopartes().getRowData());
        AutopartesDao dao = new AutopartesDaoImp();
        //   dao.remover(autoparteTemp);
        return "indexAutopartes";
    }

    public StreamedContent getImagenDinamica() {
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        String contextPath = ((ServletContext) externalContext.getContext()).getRealPath("/");
        String pathImagen = contextPath + "resources/images/xsinfondo.gif";
//        String pathImagen = System.getProperty("user.dir") + "/resources/images/xsinfondo.gif";
        String codAutoparteW = externalContext.getRequestParameterMap().get("codAutoparte");
        String cantidadImagenW = externalContext.getRequestParameterMap().get("cantidadImagen");
        if (cantidadImagenW != null) {
            Integer cantidadImagenTemp = Integer.parseInt(cantidadImagenW);
            if (cantidadImagenTemp > 0) {
                if (codAutoparteW != null && this.getListaAutopartes2() != null && !this.listaAutopartes2.isEmpty()) {
                    Integer codAutoparteTemp = Integer.parseInt(codAutoparteW);
                    for (Autopartes autoparteTemp : this.getListaAutopartes2()) {
                        if (autoparteTemp.getCodAutoparte() == codAutoparteTemp) {
                            DefaultStreamedContent dsc = new DefaultStreamedContent(new ByteArrayInputStream(autoparteTemp.getImagenAutoparte()));
                            return dsc;
                        }
                    }
                }
            } else {
                File f = new File(pathImagen);
                if (f.exists()) {
                    try {
                        InputStream stream = new FileInputStream(f);
                        DefaultStreamedContent dsc2 = new DefaultStreamedContent(stream, "image/gif");
                        return dsc2;
                    } catch (FileNotFoundException ex) {
                        Logger.getLogger(AutopartesController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    System.out.println("PATHIMAGEN NO EXISTE: " + pathImagen);
                }

            }
        }
        return new DefaultStreamedContent(new ByteArrayInputStream(this.getListaAutopartes2().get(0).getImagenAutoparte()));
        //if you return null here then it won't work!!! You have to return something.
    }

    /**
     * @return the crearActualizar
     */
    public String getCrearActualizar() {
        return crearActualizar;
    }

    /**
     * @param crearActualizar the crearActualizar to set
     */
    public void setCrearActualizar(String crearActualizar) {
        this.crearActualizar = crearActualizar;
    }

    /**
     * @return the valueBotonImagen
     */
    public String getValueBotonImagen() {
        return valueBotonImagen;
    }

    /**
     * @param valueBotonImagen the valueBotonImagen to set
     */
    public void setValueBotonImagen(String valueBotonImagen) {
        this.valueBotonImagen = valueBotonImagen;
    }

    /**
     * @return the titleBotonImagen
     */
    public String getTitleBotonImagen() {
        return titleBotonImagen;
    }

    /**
     * @param titleBotonImagen the titleBotonImagen to set
     */
    public void setTitleBotonImagen(String titleBotonImagen) {
        this.titleBotonImagen = titleBotonImagen;
    }

    /**
     * @return the iconBotonImagen
     */
    public String getIconBotonImagen() {
        return iconBotonImagen;
    }

    /**
     * @param iconBotonImagen the iconBotonImagen to set
     */
    public void setIconBotonImagen(String iconBotonImagen) {
        this.iconBotonImagen = iconBotonImagen;
    }

    /**
     * @return the autoparte
     */
    public Autopartes getAutoparte() {
        return autoparte;
    }

    /**
     * @param autoparte the autoparte to set
     */
    public void setAutoparte(Autopartes autoparte) {
        this.autoparte = autoparte;
    }

    /**
     * @return the listaAutopartes
     */
    public DataModel getListaAutopartes() {
        return listaAutopartes;
    }

    /**
     * @param listaAutopartes the listaAutopartes to set
     */
    public void setListaAutopartes(DataModel listaAutopartes) {
        this.listaAutopartes = listaAutopartes;
    }

    /**
     * @return the listaAutopartes2
     */
    public List<Autopartes> getListaAutopartes2() {
        return listaAutopartes2;
    }

    /**
     * @param listaAutopartes2 the listaAutopartes2 to set
     */
    public void setListaAutopartes2(List<Autopartes> listaAutopartes2) {
        this.listaAutopartes2 = listaAutopartes2;
    }

    /**
     * @return the buscarExpresion
     */
    public String getBuscarExpresion() {
        return buscarExpresion;
    }

    /**
     * @param buscarExpresion the buscarExpresion to set
     */
    public void setBuscarExpresion(String buscarExpresion) {
        this.buscarExpresion = buscarExpresion;
    }
}