package controlador;

import dao.ImagenesDao;
import dao.ImagenesDaoImpl;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import modelo.Autopartes;
import modelo.Imagenes;
import navegacion.ActualizarCentroBean;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
import vista.imagenPrime;

@ManagedBean
@SessionScoped
public class ImagenesController {

    private Imagenes imagen;
    private imagenPrime imaPrime;
    private DataModel listaImagenes;
    private List<Imagenes> listaImagenes2;
    private UploadedFile archivo;
    private boolean mostrarDetalles;
    private String tipoIma;
    private boolean mostrarCarrucel;
    private boolean mostrarGalleria;
    private Autopartes autoparte;

    public ImagenesController() {
        this.mostrarDetalles = false;
    }

    public void mostrarListarAdminImagenes() {
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
        //Se recupera el bean de sesion para redireccionar
        ActualizarCentroBean actualizarCentroBean = (ActualizarCentroBean) session.getAttribute("actualizarCentroBean");
        actualizarCentroBean.setIncluirPagina("./listarAdminImagenes.xhtml");
        session.setAttribute("actualizarCentroBean", actualizarCentroBean);
        setListaImagenes(new ListDataModel(new ImagenesDaoImpl().lista()));
    }

    public void mostrarImagenesPorCodAutoparte(Autopartes autopart) {
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        HttpSession session = (HttpSession) externalContext.getSession(false);
        //Se recupera el bean de sesion para redireccionar
        ActualizarCentroBean actualizarCentroBean = (ActualizarCentroBean) session.getAttribute("actualizarCentroBean");
        actualizarCentroBean.setIncluirPagina("./listarAdminImagenes.xhtml");
        session.setAttribute("actualizarCentroBean", actualizarCentroBean);
        setAutoparte(autopart);
        setListaImagenes2(new ImagenesDaoImpl().lista(getAutoparte().getCodAutoparte()));
        setListaImagenes(new ListDataModel(getListaImagenes2()));
        if (getListaImagenes2().isEmpty()) {
            setMostrarCarrucel(false);
        } else {
            setMostrarCarrucel(true);
            setListaImagenes(new ListDataModel(getListaImagenes2()));
        }
    }

    public void mostrarImagenesPorCodAutoparte2(Autopartes autopa) {
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        HttpSession session = (HttpSession) externalContext.getSession(false);
        //Se recupera el bean de sesion para redireccionar
        ActualizarCentroBean actualizarCentroBean = (ActualizarCentroBean) session.getAttribute("actualizarCentroBean");
        actualizarCentroBean.setIncluirPagina("./detalleAutopartes.xhtml");
        session.setAttribute("actualizarCentroBean", actualizarCentroBean);
        setAutoparte(autopa);
        setListaImagenes2(new ImagenesDaoImpl().lista(getAutoparte().getCodAutoparte()));
        if (getListaImagenes2().isEmpty()) {
            setMostrarGalleria(false);
        } else {
            setMostrarGalleria(true);
            setListaImagenes(new ListDataModel(getListaImagenes2()));
        }
    }

    public void prepararExcluirImagenes(Imagenes imagen) {
        //setImagen((Imagenes) (getListaImagenes().getRowData()));
        setImagen(imagen);
        setImaPrime(new imagenPrime());
        getImaPrime().setCodImagen(getImagen().getCodImagen());
        getImaPrime().setNombreImagen(getImagen().getNombreImagen());
        InputStream img = new ByteArrayInputStream(getImagen().getArchivoImagen());
        getImaPrime().setGraphicText(new DefaultStreamedContent(img, getImagen().getTipoImagen()));
        setMostrarDetalles(true);
    }

    public void excluirImagenes(String accion) {
        if (accion.equals("aceptar")) {
            ImagenesDao dao = new ImagenesDaoImpl();
            try {
                dao.remover(getImagen(), getAutoparte().getCantidadImagen());
                getAutoparte().setCantidadImagen(getAutoparte().getCantidadImagen() - 1);
                mostrarImagenesPorCodAutoparte(getAutoparte());
                FacesMessage msg = new FacesMessage("El archivo ", getImagen().getNombreImagen() + " se elimino.");
                FacesContext.getCurrentInstance().addMessage(null, msg);
            } catch (Exception e) {
                FacesMessage msg = new FacesMessage("El archivo ", getImagen().getNombreImagen() + " no se elimino.");
                FacesContext.getCurrentInstance().addMessage(null, msg);
            }


        } else if (accion.equals("cancelar")) {
            imaPrime = null;
            setImagen(null);
            mostrarDetalles = false;
        } else if (accion.equals("cerrar")) {
            mostrarDetalles = false;
        }

    }

//    public void prepararAdicionarImagenes(int codAutoparte) {
//        imagen = new Imagenes();
//        imagen.setAutopartes(new Autopartes());
//        imagen.getAutopartes().setCodAutoparte(codAutoparte);
//        archivo = new DefaultUploadedFile();
//    }
    public void adicionarImagenesAutomaticamente(FileUploadEvent event) {
        String codAutoparteW = event.getComponent().getAttributes().get("codAutoparte").toString();
        Integer codAutoparteTemp = Integer.parseInt(codAutoparteW);
        System.out.println("canti: " + getAutoparte().getCantidadImagen());
        setImagen(new Imagenes());
        try {
            getImagen().setNombreImagen(event.getFile().getFileName());
            //        getImagen().setArchivoImagen(event.getFile().getContents());
            getImagen().setArchivoImagen(ajustaImagen(event.getFile().getContents(), 640, 480, event.getFile().getContentType()));
            getImagen().setTipoImagen(event.getFile().getContentType());
            getImagen().setFkCodAutoparte(codAutoparteTemp);
            ImagenesDao dao = new ImagenesDaoImpl();
            dao.guardar(getImagen(), getAutoparte().getCantidadImagen());
            getAutoparte().setCantidadImagen(getAutoparte().getCantidadImagen() + 1);
            mostrarImagenesPorCodAutoparte(getAutoparte());
            FacesMessage msg = new FacesMessage("El archivo ", getImagen().getNombreImagen() + " se cargo.");
            FacesContext.getCurrentInstance().addMessage(null, msg);
        } catch (Exception ex) {
            Logger.getLogger(ImagenesController.class.getName()).log(Level.SEVERE, null, ex);
            FacesMessage msg = new FacesMessage("El archivo ", getImagen().getNombreImagen() + " no se cargo.");
            FacesContext.getCurrentInstance().addMessage(null, msg);
        }
    }

    private byte[] ajustaImagen(byte[] imagen, int IMG_WIDTH, int IMG_HEIGHT, String tipoImagen) throws Exception {
        String tipo = "";
        if(tipoImagen.equals("image/jpeg") || tipoImagen.equals("image/jpg")){
            tipo = "jpg";
        }else if(tipoImagen.equals("image/png")){
            tipo = "png";
        }else if(tipoImagen.equals("image/gif")){
            tipo = "gif";
        }
        
        InputStream inputStream = new ByteArrayInputStream(imagen);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            BufferedImage originalImage = ImageIO.read(inputStream);
            int type = originalImage.getType() == 0 ? BufferedImage.TYPE_INT_ARGB : originalImage.getType();

            BufferedImage resizedImage = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, type);
            Graphics2D g = resizedImage.createGraphics();
            g.drawImage(originalImage, 0, 0, IMG_WIDTH, IMG_HEIGHT, null);
            g.dispose();
            g.setComposite(AlphaComposite.Src);

            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            ImageIO.write(resizedImage, tipo, baos);
        } catch (Throwable ex) {
            throw new Exception("Error proceso Tamaño Imagen " + ex.toString(), ex);
        }
        return baos.toByteArray();
    }

    public void adicionarImagenes() {
        if (archivo != null) {
            System.out.println("no es null");
            getImagen().setNombreImagen(archivo.getFileName());
            getImagen().setArchivoImagen(archivo.getContents());
            getImagen().setTipoImagen(archivo.getContentType());
            ImagenesDao dao = new ImagenesDaoImpl();
//            dao.guardar(imagen);
            FacesMessage msg = new FacesMessage("El archivo ", archivo.getFileName() + " se cargo.");
            FacesContext.getCurrentInstance().addMessage(null, msg);
        } else {
            System.out.println("es null");
        }
    }

    public void prepararAlterarImagenes() {
        setImagen((Imagenes) (getListaImagenes().getRowData()));
        setImaPrime(new imagenPrime());
        getImaPrime().setCodImagen(getImagen().getCodImagen());
        getImaPrime().setNombreImagen(getImagen().getNombreImagen());
        InputStream img = new ByteArrayInputStream(getImagen().getArchivoImagen());
        getImaPrime().setGraphicText(new DefaultStreamedContent(img, getImagen().getTipoImagen()));
    }

    public String alterarImagenes() {
        ImagenesDao dao = new ImagenesDaoImpl();
//        dao.actualizar(imagen);
        return "index";
    }

    public StreamedContent getImagenDinamica() {
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        String contextPath = ((ServletContext) externalContext.getContext()).getRealPath("/");
        String pathImagen = contextPath + "resources/images/xsinfondo.gif";
//        String pathImagen = System.getProperty("user.dir") + "/resources/images/xsinfondo.gif";

        String codImagenW = externalContext.getRequestParameterMap().get("codImagen");
        System.out.println("CO " + codImagenW);
        if (codImagenW != null && this.getListaImagenes2() != null && !this.listaImagenes2.isEmpty()) {
            Integer codImagenTemp = Integer.parseInt(codImagenW);
            for (Imagenes imagenTemp : this.getListaImagenes2()) {
                if (imagenTemp.getCodImagen() == codImagenTemp) {
                    DefaultStreamedContent dsc = new DefaultStreamedContent(new ByteArrayInputStream(imagenTemp.getArchivoImagen()), imagenTemp.getTipoImagen());
                    dsc.setName(imagenTemp.getNombreImagen());
                    dsc.setContentType(imagenTemp.getTipoImagen());
                    return dsc;
                }
            }
        }
//        else {
//            System.out.println("PATH: " + pathImagen);
//            File f = new File(pathImagen);
//            if (f.exists()) {
//                try {
//                    InputStream stream = new FileInputStream(f);
//                    DefaultStreamedContent dsc2 = new DefaultStreamedContent(stream, "image/gif");
//                    return dsc2;
//                } catch (FileNotFoundException ex) {
//                    Logger.getLogger(ImagenesController.class.getName()).log(Level.SEVERE, null, ex);
//                }
//            } else {
//                System.out.println("PATHIMAGEN NO EXISTE: " + pathImagen);
//            }
//        }


        return new DefaultStreamedContent(new ByteArrayInputStream(this.getListaImagenes2().get(0).getArchivoImagen()), this.getListaImagenes2().get(0).getTipoImagen());
        //if you return null here then it won't work!!! You have to return something.
    }

    /**
     * @return the archivo
     */
    public UploadedFile getArchivo() {
        return archivo;
    }

    /**
     * @param archivo the archivo to set
     */
    public void setArchivo(UploadedFile archivo) {
        this.archivo = archivo;
    }

    /**
     * @return the imaPrime
     */
    public imagenPrime getImaPrime() {
        return imaPrime;
    }

    /**
     * @param imaPrime the imaPrime to set
     */
    public void setImaPrime(imagenPrime imaPrime) {
        this.imaPrime = imaPrime;
    }

    /**
     * @return the mostrarDetalles
     */
    public boolean isMostrarDetalles() {
        return mostrarDetalles;
    }

    /**
     * @param mostrarDetalles the mostrarDetalles to set
     */
    public void setMostrarDetalles(boolean mostrarDetalles) {
        this.mostrarDetalles = mostrarDetalles;
    }

    /**
     * @return the imagen
     */
    public Imagenes getImagen() {
        return imagen;
    }

    /**
     * @param imagen the imagen to set
     */
    public void setImagen(Imagenes imagen) {
        this.imagen = imagen;
    }

    /**
     * @return the listaImagenes
     */
    public DataModel getListaImagenes() {
        return listaImagenes;
    }

    /**
     * @param listaImagenes the listaImagenes to set
     */
    public void setListaImagenes(DataModel listaImagenes) {
        this.listaImagenes = listaImagenes;
    }

    /**
     * @return the listaImagenes2
     */
    public List<Imagenes> getListaImagenes2() {
        return listaImagenes2;
    }

    /**
     * @param listaImagenes2 the listaImagenes2 to set
     */
    public void setListaImagenes2(List<Imagenes> listaImagenes2) {
        this.listaImagenes2 = listaImagenes2;
    }

    /**
     * @return the tipoIma
     */
    public String getTipoIma() {
        return tipoIma;
    }

    /**
     * @param tipoIma the tipoIma to set
     */
    public void setTipoIma(String tipoIma) {
        this.tipoIma = tipoIma;
    }

    /**
     * @return the mostrarCarrucel
     */
    public boolean isMostrarCarrucel() {
        return mostrarCarrucel;
    }

    /**
     * @param mostrarCarrucel the mostrarCarrucel to set
     */
    public void setMostrarCarrucel(boolean mostrarCarrucel) {
        this.mostrarCarrucel = mostrarCarrucel;
    }

    /**
     * @return the autoparte
     */
    public Autopartes getAutoparte() {
        return autoparte;
    }

    /**
     * @param autoparte the autoparte to set
     */
    public void setAutoparte(Autopartes autoparte) {
        this.autoparte = autoparte;
    }

    /**
     * @return the mostrarGalleria
     */
    public boolean isMostrarGalleria() {
        return mostrarGalleria;
    }

    /**
     * @param mostrarGalleria the mostrarGalleria to set
     */
    public void setMostrarGalleria(boolean mostrarGalleria) {
        this.mostrarGalleria = mostrarGalleria;
    }
}
