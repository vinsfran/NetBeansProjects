package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//Clsse conector que hace la coneccion a la base de datos postgresql.
public class Conector {

    private static Connection c = null;

    //Metodo por el cual se crea la coneccion para poder usar.
    public static Connection getConnection() {
        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql://126.10.10.10:5432/sisrepuestos_db", "simeac", "simeac01");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return c;
    }

    static void releaseConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
            }
        }
    }

    public static void releaseConnection() {
        if (c != null) {
            try {
                c.close();
            } catch (SQLException e) {
            }
        }
    }
}
