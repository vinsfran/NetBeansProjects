package navegacion;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

/**
 *
 * @author vinsfran
 */
@ManagedBean
@SessionScoped
public class ActualizarCentroBean {

    private String incluirPagina;
    private boolean mostrarLogin;
    private String username;
    private String password;

    public ActualizarCentroBean() {
        this.username = "";
        this.password = "";
        this.mostrarLogin = false;
        this.incluirPagina = "./bienvenida.xhtml";
    }

    public void navegador(String incluirPagina) {
        this.incluirPagina = incluirPagina;
    }

    public void mostrarDialogoLogin() {
        setMostrarLogin(true);
    }

    public void ocultarDialogoLogin() {
        setMostrarLogin(false);
        setUsername("");
        setPassword("");
    }

    public void validar() {
        System.out.println("");
        if (username.equals("vinsfran") && password.equals("123")) {
            setIncluirPagina("./bienvenidaadmin.xhtml");
            ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
            String ctxPath = ((ServletContext) ctx.getContext()).getContextPath();
            try {
                ctx.redirect(ctxPath + "/faces/indexadmin.xhtml");
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } else {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_WARN, "Usuario y/o Clave Incorrectos!", ""));
        }
    }

    public void salir() {
        ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
        String ctxPath = ((ServletContext) ctx.getContext()).getContextPath();
        HttpSession session = (HttpSession) ctx.getSession(false);
        if (session != null) {
            session.invalidate(); //CERRAR SESION
            try {
                ctx.redirect(ctxPath);
            } catch (IOException ex) {
                Logger.getLogger(ActualizarCentroBean.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            System.out.println("Sesiom NULL");
        }
    }

    /**
     * @return the incluirPagina
     */
    public String getIncluirPagina() {
        return incluirPagina;
    }

    /**
     * @param incluirPagina the incluirPagina to set
     */
    public void setIncluirPagina(String incluirPagina) {
        this.incluirPagina = incluirPagina;
    }

    /**
     * @return the mostrarLogin
     */
    public boolean isMostrarLogin() {
        return mostrarLogin;
    }

    /**
     * @param mostrarLogin the mostrarLogin to set
     */
    public void setMostrarLogin(boolean mostrarLogin) {
        this.mostrarLogin = mostrarLogin;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
