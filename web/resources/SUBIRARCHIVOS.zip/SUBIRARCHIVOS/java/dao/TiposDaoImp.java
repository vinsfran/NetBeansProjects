package dao;

import conexion.Conector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Tipos;

public class TiposDaoImp implements TiposDao {

    @Override
    public void guardar(Tipos tipo) {
        //Metodo para insertar los tipos de autopartes en la BD.
        Connection con = Conector.getConnection();
        PreparedStatement pstm;
        try {
            con = Conector.getConnection();
            con.setAutoCommit(false);
            pstm = con.prepareStatement("INSERT INTO tipos(nombre_tipo) VALUES (?);");
            pstm.setString(1, tipo.getNombreTipo().toUpperCase());
            pstm.executeUpdate();
            con.commit();
        } catch (SQLException e) {
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException ex) {
                    Logger.getLogger(TiposDaoImp.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.out.println("Connection rollback...");
            }
            e.printStackTrace();
        } finally {
            try {
                Conector.releaseConnection();
                con.close();
                System.out.println("CONE CERRADA");
            } catch (SQLException ex) {
                Logger.getLogger(TiposDaoImp.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

//
//    @Override
//    public Tipos getTipo(int codTipo) {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        Tipos t = (Tipos) session.load(Tipos.class, codTipo);
//        session.close();        
//        return t;
//    }
//
    @Override
    public List<Tipos> lista() {
        //Metodo para listar las imagenes en la BD.
        Connection con = Conector.getConnection();
        Statement stmt = null;
        ResultSet rs = null;
        List<Tipos> lista = new ArrayList();
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            rs = stmt.executeQuery("SELECT cod_tipo, nombre_tipo FROM tipos ORDER BY cod_tipo;");
            while (rs.next()) {
                Tipos t = new Tipos();
                t.setCodTipo(rs.getInt("cod_tipo"));
                t.setNombreTipo(rs.getString("nombre_tipo"));
                lista.add(t);


            }
        } catch (SQLException ex) {
            Logger.getLogger(AutopartesDaoImp.class
                    .getName()).log(Level.SEVERE, null, ex);

            return null;
        }
        return lista;
    }
//
//    @Override
//    public void remover(Tipos tipo) {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        Transaction t = session.beginTransaction();
//        session.delete(tipo);
//        t.commit();
//        session.close();
//    }
//

    @Override
    public void actualizar(Tipos tipo) {
        //Metodo para actualizar los tipos autopartes de la BD.
        Connection con = Conector.getConnection();
        PreparedStatement pstm;
        try {
            con = Conector.getConnection();
            con.setAutoCommit(false);
            pstm = con.prepareStatement("UPDATE tipos set "
                    + "nombre_tipo= ? "
                    + "WHERE cod_tipo= ?;");
            pstm.setString(1, tipo.getNombreTipo().toUpperCase());
            pstm.setInt(2, tipo.getCodTipo());
            pstm.executeUpdate();
            con.commit();
        } catch (SQLException e) {
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException ex) {
                    Logger.getLogger(ImagenesDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.out.println("Connection rollback...");
            }
            e.printStackTrace();
        } finally {
            try {
                Conector.releaseConnection();
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ImagenesDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }
}
