package dao;

import java.util.List;
import modelo.Tipos;

public interface TiposDao {

    public void guardar(Tipos tipo);
//
//    public Tipos getTipo(int codTipo);
//
    public List<Tipos> lista();
//
//    public void remover(Tipos tipo);
//

    public void actualizar(Tipos tipo);
}
