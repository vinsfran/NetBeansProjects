package dao;

import conexion.Conector;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Imagenes;

public class ImagenesDaoImpl implements ImagenesDao {

    @Override
    public void guardar(Imagenes imagen, int cantidadImagenes) {
        //Metodo para insertar las imagenes en la BD.
        Connection con = Conector.getConnection();

        try {
            InputStream archivo = new ByteArrayInputStream(imagen.getArchivoImagen());
            con = Conector.getConnection();
            con.setAutoCommit(false);
            PreparedStatement pstm = con.prepareStatement("INSERT INTO imagenes(nombre_imagen, archivo_imagen, tipo_imagen, fk_cod_autoparte) "
                    + "VALUES (?, ?, ?, ?);");
            pstm.setString(1, imagen.getNombreImagen());
            pstm.setBinaryStream(2, archivo, imagen.getArchivoImagen().length);
            pstm.setString(3, imagen.getTipoImagen());
            pstm.setInt(4, imagen.getFkCodAutoparte());
            pstm.executeUpdate();

//            pstm = con.prepareStatement("UPDATE autopartes set "
//                    + "cantidad_imagen= cantidad_imagen + 1 "
//                    + "WHERE cod_autoparte= ?;");
//            pstm.setInt(1, imagen.getFkCodAutoparte());

            if (cantidadImagenes < 1) {
                System.out.println("ENTRO IMA");
                pstm = con.prepareStatement("UPDATE autopartes set "
                        + "cantidad_imagen= cantidad_imagen + 1, imagen_autoparte= ? "
                        + "WHERE cod_autoparte= ?;");
                pstm.setBytes(1, imagen.getArchivoImagen());
                pstm.setInt(2, imagen.getFkCodAutoparte());
            } else {
                pstm = con.prepareStatement("UPDATE autopartes set "
                        + "cantidad_imagen= cantidad_imagen + 1 "
                        + "WHERE cod_autoparte= ?;");
                pstm.setInt(1, imagen.getFkCodAutoparte());
            }
            pstm.executeUpdate();

            con.commit();
        } catch (SQLException e) {
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException ex) {
                    Logger.getLogger(ImagenesDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.out.println("Connection rollback...");
            }
            e.printStackTrace();
        } finally {
            try {
                Conector.releaseConnection();
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ImagenesDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }
//
//    @Override
//    public Imagenes getImagen(int codImagen) {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        Imagenes i = (Imagenes) session.load(Imagenes.class, codImagen);
//        session.close();
//        return i;
//    }
//

    @Override
    public List<Imagenes> lista() {
        //Metodo para listar las imagenes en la BD.
        Connection con = Conector.getConnection();
        Statement stmt = null;
        ResultSet rs = null;
        List<Imagenes> lista = new ArrayList();
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            rs = stmt.executeQuery("SELECT "
                    + "cod_imagen, nombre_imagen, archivo_imagen, tipo_imagen, fk_cod_autoparte "
                    + "FROM imagenes;");
            while (rs.next()) {
                Imagenes i = new Imagenes();
                i.setCodImagen(rs.getInt("cod_imagen"));
                i.setNombreImagen(rs.getString("nombre_imagen"));
                i.setArchivoImagen(rs.getBytes("archivo_imagen"));
                i.setTipoImagen(rs.getString("tipo_imagen"));
                i.setFkCodAutoparte(rs.getInt("fk_cod_autoparte"));
                lista.add(i);


            }
        } catch (SQLException ex) {
            Logger.getLogger(AutopartesDaoImp.class
                    .getName()).log(Level.SEVERE, null, ex);

            return null;
        }
        return lista;
    }

    @Override
    public List<Imagenes> lista(int codAutoParte) {
        //Metodo para listar las imagenes en la BD.
        Connection con = Conector.getConnection();
        Statement stmt = null;
        ResultSet rs = null;
        List<Imagenes> lista = new ArrayList();
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            rs = stmt.executeQuery("SELECT "
                    + "cod_imagen, nombre_imagen, archivo_imagen, tipo_imagen, fk_cod_autoparte "
                    + "FROM imagenes "
                    + "WHERE fk_cod_autoparte = " + codAutoParte + ";");
            while (rs.next()) {
                Imagenes i = new Imagenes();
                i.setCodImagen(rs.getInt("cod_imagen"));
                i.setNombreImagen(rs.getString("nombre_imagen"));
                i.setArchivoImagen(rs.getBytes("archivo_imagen"));
                i.setTipoImagen(rs.getString("tipo_imagen"));
                i.setFkCodAutoparte(rs.getInt("fk_cod_autoparte"));
                lista.add(i);


            }
        } catch (SQLException ex) {
            Logger.getLogger(AutopartesDaoImp.class
                    .getName()).log(Level.SEVERE, null, ex);

            return null;
        }
        return lista;
    }
//

    @Override
    public void remover(Imagenes imagen, int cantidadImagenes) {
        //Metodo para eliminar las imagenes de la BD.
        Connection con = Conector.getConnection();
        PreparedStatement pstm;
        try {
            con = Conector.getConnection();
            con.setAutoCommit(false);

            pstm = con.prepareStatement("DELETE FROM imagenes WHERE cod_imagen = ?;");
            pstm.setInt(1, imagen.getCodImagen());
            pstm.executeUpdate();

            if (cantidadImagenes < 2) {
                pstm = con.prepareStatement("UPDATE autopartes set "
                        + "cantidad_imagen= cantidad_imagen - 1, imagen_autoparte= ? "
                        + "WHERE cod_autoparte= ?;");
                pstm.setBytes(1, new byte[cantidadImagenes]);
                pstm.setInt(2, imagen.getFkCodAutoparte());
            }else{
                pstm = con.prepareStatement("UPDATE autopartes set "
                        + "cantidad_imagen= cantidad_imagen - 1 "
                        + "WHERE cod_autoparte= ?;");
                pstm.setInt(1, imagen.getFkCodAutoparte());
            }


            pstm.executeUpdate();

            con.commit();
        } catch (SQLException e) {
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException ex) {
                    Logger.getLogger(ImagenesDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.out.println("Connection rollback...");
            }
            e.printStackTrace();
        } finally {
            try {
                Conector.releaseConnection();
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ImagenesDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }
//
//    @Override
//    public void actualizar(Imagenes imagen) {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        Transaction t = session.beginTransaction();
//        session.update(imagen);
//        t.commit();
//        session.close();
//    }
}
