package dao;

import java.util.List;
import modelo.Imagenes;

/**
 *
 * @author User
 */
public interface ImagenesDao {

    public void guardar(Imagenes imagen, int cantidadImagenes);
//
//    public Imagenes getImagen(int codImagen);
//

    public List<Imagenes> lista();

    public List<Imagenes> lista(int codAutoparte);
//

    public void remover(Imagenes imagen, int cantidadImagenes);
//
//    public void actualizar(Imagenes imagen);
}
