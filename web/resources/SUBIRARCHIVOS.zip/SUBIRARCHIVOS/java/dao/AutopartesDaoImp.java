package dao;

import conexion.Conector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Autopartes;
import modelo.Tipos;

public class AutopartesDaoImp implements AutopartesDao {

    @Override
    public void guardar(Autopartes autoparte) {
        //Metodo para insertar las autopartes en la BD.
        Connection con = Conector.getConnection();
        PreparedStatement pstm;
        try {

            con = Conector.getConnection();
            pstm = con.prepareStatement("INSERT INTO autopartes("
                    + "nro_parte, "
                    + "nombre_autoparte, "
                    + "descripcion_autoparte, "
                    + "cantidad, "
                    + "precio, "
                    + "fk_cod_tipo) "
                    + "VALUES (?, ?, ?, ?,?,?);");
            pstm.setString(1, autoparte.getNroParte().toUpperCase());
            pstm.setString(2, autoparte.getNombreAutoparte().toUpperCase());
            pstm.setString(3, autoparte.getDescripcionAutoparte().toUpperCase());
            pstm.setInt(4, autoparte.getCantidad());
            pstm.setInt(5, autoparte.getPrecio());
            pstm.setInt(6, autoparte.getTipo().getCodTipo());
            pstm.execute();
            pstm.close();
        } catch (SQLException ex) {
            Logger.getLogger(AutopartesDaoImp.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                Conector.releaseConnection();
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(AutopartesDaoImp.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }
//    @Override
//    public Autopartes getAutoparte(int codAutoparte) {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        Autopartes a = (Autopartes) session.load(Autopartes.class, codAutoparte);
//        session.close();
//        return a;
//    }

    @Override
    public List<Autopartes> lista() {
        Connection con = Conector.getConnection();
        List<Autopartes> lista = new ArrayList();
        try {
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("SELECT "
                    + "a.cod_autoparte, a.nro_parte, a.nombre_autoparte, "
                    + "a.descripcion_autoparte, a.cantidad, a.precio, t.cod_tipo, "
                    + "a.cantidad_imagen, a.imagen_autoparte, t.nombre_tipo "
                    + "FROM "
                    + "autopartes AS a, tipos AS t "
                    + "WHERE "
                    + "a.fk_cod_tipo = t.cod_tipo "
                    + "ORDER BY "
                    + "a.cod_autoparte;");
            while (rs.next()) {
                Autopartes a = new Autopartes();
                a.setCodAutoparte(rs.getInt("cod_autoparte"));
                a.setNroParte(rs.getString("nro_parte"));
                a.setNombreAutoparte(rs.getString("nombre_autoparte"));
                a.setDescripcionAutoparte(rs.getString("descripcion_autoparte"));
                a.setCantidad(rs.getInt("cantidad"));
                a.setPrecio(rs.getInt("precio"));
                a.setTipo(new Tipos());
                a.getTipo().setCodTipo(rs.getInt("cod_tipo"));
                a.getTipo().setNombreTipo(rs.getString("nombre_tipo"));
                a.setCantidadImagen(rs.getInt("cantidad_imagen"));
                a.setImagenAutoparte(rs.getBytes("imagen_autoparte"));
                lista.add(a);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AutopartesDaoImp.class
                    .getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return lista;
    }

    @Override
    public List<Autopartes> buscar(String expresion) {
        Connection con = Conector.getConnection();
        List<Autopartes> lista = new ArrayList();
        try {
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("SELECT "
                    + "a.cod_autoparte, a.nro_parte, a.nombre_autoparte, "
                    + "a.descripcion_autoparte, a.cantidad, a.precio, t.cod_tipo, "
                    + "a.cantidad_imagen, a.imagen_autoparte, t.nombre_tipo "
                    + "FROM "
                    + "autopartes AS a, tipos AS t "
                    + "WHERE "
                    + "a.fk_cod_tipo = t.cod_tipo "
                    + "AND "
                    + "(a.nro_parte LIKE '%" + expresion + "%' "
                    + "OR "
                    + "a.nombre_autoparte LIKE '%" + expresion + "%' "
                    + "OR "
                    + "a.descripcion_autoparte LIKE '%" + expresion + "%' "
                    + "OR "
                    + "t.nombre_tipo LIKE '%" + expresion + "%') "
                    + "ORDER BY "
                    + "a.cod_autoparte;");
            while (rs.next()) {
                Autopartes a = new Autopartes();
                a.setCodAutoparte(rs.getInt("cod_autoparte"));
                a.setNroParte(rs.getString("nro_parte"));
                a.setNombreAutoparte(rs.getString("nombre_autoparte"));
                a.setDescripcionAutoparte(rs.getString("descripcion_autoparte"));
                a.setCantidad(rs.getInt("cantidad"));
                a.setPrecio(rs.getInt("precio"));
                a.setTipo(new Tipos());
                a.getTipo().setCodTipo(rs.getInt("cod_tipo"));
                a.getTipo().setNombreTipo(rs.getString("nombre_tipo"));
                a.setCantidadImagen(rs.getInt("cantidad_imagen"));
                a.setImagenAutoparte(rs.getBytes("imagen_autoparte"));
                lista.add(a);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AutopartesDaoImp.class
                    .getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return lista;
    }

//    @Override
//    public void remover(Autopartes autoparte) {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        Transaction t = session.beginTransaction();
//        session.delete(autoparte);
//        t.commit();
//        session.close();
//    }
//
    @Override
    public void actualizar(Autopartes autoparte) {
        //Metodo para actualizar las autopartes de la BD.
        Connection con = Conector.getConnection();
        PreparedStatement pstm;
        try {
            con = Conector.getConnection();
            pstm = con.prepareStatement("UPDATE autopartes set "
                    + "nro_parte= ?, nombre_autoparte= ?, descripcion_autoparte= ?, cantidad= ?, precio= ?, fk_cod_tipo= ? "
                    + "WHERE cod_autoparte= ?;");
            pstm.setString(1, autoparte.getNroParte().toUpperCase());
            pstm.setString(2, autoparte.getNombreAutoparte().toUpperCase());
            pstm.setString(3, autoparte.getDescripcionAutoparte().toUpperCase());
            pstm.setInt(4, autoparte.getCantidad());
            pstm.setInt(5, autoparte.getPrecio());
            pstm.setInt(6, autoparte.getTipo().getCodTipo());
            pstm.setInt(7, autoparte.getCodAutoparte());
            pstm.execute();
            pstm.close();

        } catch (SQLException ex) {
            Logger.getLogger(AutopartesDaoImp.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                Conector.releaseConnection();
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(AutopartesDaoImp.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }
}