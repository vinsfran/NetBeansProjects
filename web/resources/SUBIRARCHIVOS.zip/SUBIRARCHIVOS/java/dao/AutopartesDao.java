package dao;

import java.util.List;
import modelo.Autopartes;

public interface AutopartesDao {

    public void guardar(Autopartes autoparte);

//    public Autopartes getAutoparte(int codAutoparte);
    public List<Autopartes> lista();

    public List<Autopartes> buscar(String expresion);
//    public void remover(Autopartes autoparte);

    public void actualizar(Autopartes autoparte);
}