package modelo;

public class Tipos implements java.io.Serializable {

    private int codTipo;
    private String nombreTipo;

    public Tipos() {
    }

    public Tipos(int codTipo, String nombreTipo) {
        this.codTipo = codTipo;
        this.nombreTipo = nombreTipo;
    }

    public int getCodTipo() {
        return this.codTipo;
    }

    public void setCodTipo(int codTipo) {
        this.codTipo = codTipo;
    }

    public String getNombreTipo() {
        return this.nombreTipo;
    }

    public void setNombreTipo(String nombreTipo) {
        this.nombreTipo = nombreTipo;
    }
}
