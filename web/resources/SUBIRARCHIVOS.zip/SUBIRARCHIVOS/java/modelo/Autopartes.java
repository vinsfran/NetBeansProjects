package modelo;

public class Autopartes implements java.io.Serializable {

    private int codAutoparte;
    private String nroParte;
    private String nombreAutoparte;
    private String descripcionAutoparte;
    private Integer cantidad;
    private Integer precio;
    private Tipos tipo;
    private int cantidadImagen;
    private byte[] imagenAutoparte;

    public Autopartes() {
    }

    public Autopartes(int codAutoparte, Tipos tipo) {
        this.codAutoparte = codAutoparte;
        this.tipo = tipo;
    }

    public Autopartes(int codAutoparte, String nroParte, String nombreAutoparte, String descripcionAutoparte, Integer cantidad, Integer precio, Tipos tipo, byte[] imagenAutoparte) {
        this.codAutoparte = codAutoparte;
        this.nroParte = nroParte;
        this.nombreAutoparte = nombreAutoparte;
        this.descripcionAutoparte = descripcionAutoparte;
        this.cantidad = cantidad;
        this.precio = precio;
        this.tipo = tipo;
        this.imagenAutoparte = imagenAutoparte;
    }

    /**
     * @return the codAutoparte
     */
    public int getCodAutoparte() {
        return codAutoparte;
    }

    /**
     * @param codAutoparte the codAutoparte to set
     */
    public void setCodAutoparte(int codAutoparte) {
        this.codAutoparte = codAutoparte;
    }

    /**
     * @return the nroParte
     */
    public String getNroParte() {
        return nroParte;
    }

    /**
     * @param nroParte the nroParte to set
     */
    public void setNroParte(String nroParte) {
        this.nroParte = nroParte;
    }

    /**
     * @return the nombreAutoparte
     */
    public String getNombreAutoparte() {
        return nombreAutoparte;
    }

    /**
     * @param nombreAutoparte the nombreAutoparte to set
     */
    public void setNombreAutoparte(String nombreAutoparte) {
        this.nombreAutoparte = nombreAutoparte;
    }

    /**
     * @return the descripcionAutoparte
     */
    public String getDescripcionAutoparte() {
        return descripcionAutoparte;
    }

    /**
     * @param descripcionAutoparte the descripcionAutoparte to set
     */
    public void setDescripcionAutoparte(String descripcionAutoparte) {
        this.descripcionAutoparte = descripcionAutoparte;
    }

    /**
     * @return the cantidad
     */
    public Integer getCantidad() {
        return cantidad;
    }

    /**
     * @param cantidad the cantidad to set
     */
    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    /**
     * @return the precio
     */
    public Integer getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(Integer precio) {
        this.precio = precio;
    }

    /**
     * @return the tipo
     */
    public Tipos getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(Tipos tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the cantidadImagen
     */
    public int getCantidadImagen() {
        return cantidadImagen;
    }

    /**
     * @param cantidadImagen the cantidadImagen to set
     */
    public void setCantidadImagen(int cantidadImagen) {
        this.cantidadImagen = cantidadImagen;
    }

    /**
     * @return the imagenAutoparte
     */
    public byte[] getImagenAutoparte() {
        return imagenAutoparte;
    }

    /**
     * @param imagenAutoparte the imagenAutoparte to set
     */
    public void setImagenAutoparte(byte[] imagenAutoparte) {
        this.imagenAutoparte = imagenAutoparte;
    }
}
